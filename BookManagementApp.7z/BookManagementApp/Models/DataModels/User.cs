﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BookManagementApp.Models.Interfaces;

namespace BookManagementApp.Models.DataModels
{
    public class User : IUser
    {
        public int UserId { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public string FirstName { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public string LastName { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public int Age { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
    }
}