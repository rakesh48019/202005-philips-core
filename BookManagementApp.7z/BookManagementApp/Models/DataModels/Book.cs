﻿using System;
using System.Collections.Generic;
using System.EnterpriseServices.Internal;
using System.Linq;
using System.Web;
using BookManagementApp.Models.Interfaces;

namespace BookManagementApp.Models.DataModels
{
    public class Book : IBook
    {
        private static List<Book> _listOfBooks = new List<Book>();

        public int? BookId { get; set; }
        public string BookName { get; set; }
        public IAuthor Author { get; set; }

        /// <summary>
        /// Creating the list of books as we don't have any DB 
        /// </summary>
        public void GenerateListOfBooks()
        {
            for (var i = 0; i < 10; i++)
            {
                var newBook = new Book()
                {
                    BookId = i,
                    BookName = $"TextBook_{i}",
                    Author = new Author()
                    {
                        Age = i + 20,
                        AuthorDisplayName = $"Author{i + 20}",
                        FirstName = $"Author{i + 20}",
                        LastName = $"Author_lastName",
                        UserId = i + 100
                    }
                };
                _listOfBooks.Add(newBook);
            }
        }

        public IEnumerable<Book> GetListOfBooks()
        {
            foreach (var bookItems in _listOfBooks)
            {
                yield return bookItems;
            }
        }
    }
}