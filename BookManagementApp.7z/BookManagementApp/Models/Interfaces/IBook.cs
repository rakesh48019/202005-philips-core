﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookManagementApp.Models.Interfaces
{
    public interface IBook
    {
        int? BookId { get; set; }
        string BookName { get; set; }
        IAuthor Author { get; set; }
    }
}
