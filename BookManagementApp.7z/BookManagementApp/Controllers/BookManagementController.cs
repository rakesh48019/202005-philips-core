﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BookManagementApp.Models.DataModels;

namespace BookManagementApp.Controllers
{
    public class BookManagementController : Controller
    {
        // GET: BookManagement
        public ActionResult Index()
        {
            //initialize Books
            var bookModel = new Book();
            bookModel.GenerateListOfBooks();

            return View(bookModel);
        }

        public ActionResult BookPage(int? id)
        {
            var bookList = new Book();
            var bookItem = bookList.GetListOfBooks().ToList().Where(p => p.BookId.Value == id).FirstOrDefault();

            return View(bookItem);
        }
    }
}